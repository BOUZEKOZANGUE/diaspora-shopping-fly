<div class="mt-6 flex flex-wrap gap-3">
    <button class="filter-btn active px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-full transition-all duration-300">
        Tous
    </button>
    <button class="filter-btn px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-full transition-all duration-300">
        En attente
    </button>
    <button class="filter-btn px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-full transition-all duration-300">
        En transit
    </button>
    <button class="filter-btn px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-full transition-all duration-300">
        Livrés
    </button>
</div>
