<thead>
    <tr class="bg-gradient-to-r from-blue-50 to-blue-100">
        <th class="px-4 py-4">
            <input type="checkbox" id="select-all"
                class="rounded border-gray-300 text-[#0077be] focus:ring-[#0077be] transition-all cursor-pointer">
        </th>
        <th class="px-6 py-4 text-left text-sm font-semibold text-[#0077be]">N° Suivi</th>
        <th class="px-6 py-4 text-left text-sm font-semibold text-[#0077be]">Client</th>
        <th class="px-6 py-4 text-left text-sm font-semibold text-[#0077be]">Statut</th>
        <th class="hidden md:table-cell px-6 py-4 text-left text-sm font-semibold text-[#0077be]">Destination</th>
        <th class="px-6 py-4 text-left text-sm font-semibold text-[#0077be]">Prix</th>
        <th class="px-6 py-4 text-left text-sm font-semibold text-[#0077be]">Date de création</th>
        <th class="px-6 py-4 text-left text-sm font-semibold text-[#0077be]">Actions</th>
    </tr>
</thead>
